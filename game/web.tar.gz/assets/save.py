"""High score persistence using JSON (profile).

Desktop: writes <game>/highscores.json
Web (Pyodide/pygbag via pygbag): uses browser localStorage "bambooforest_profile"
  (survives refresh). Direct FS open() is unreliable under WASM (pyodide FS
  often in-memory only or needs IDBFS mount + sync); we route all web I/O
  through localStorage to avoid silent fails reported in prior runs.

Versioned saves (current: 2). Old plain {"high_scores": [...]} files are
auto-migrated on load.

Cloud / backup:
- Desktop: copy the highscores.json file next to the game.
- Web: DevTools → Application → Local Storage (origin) → copy the value of
  key "bambooforest_profile" (or use JSON export). Paste back to restore.
No built-in cloud sync.

Unlocks (ice magic, glide, ...) and other meta are persisted with the profile.
"""

import json
import os
import sys
from pathlib import Path
from config import SAVE_FILE, DEFAULT_ACCESSIBILITY

MAX_SCORES: int = 5
SAVE_VERSION: int = 2

# Crash / diagnostic logger (required per workspace rules) - safe for lib import + web
sys.path.insert(0, str(Path.home() / ".claude" / "scripts"))
try:
    from crash_logger import log_event
except Exception:
    def log_event(*a, **k): pass

# Web detection (pygbag / emscripten / pyodide)
_IS_WEB = False
try:
    if ("pyodide" in sys.modules or
        "js" in sys.modules or
        getattr(sys, "platform", "") == "emscripten" or
        "emscripten" in os.environ.get("PYTHONPATH", "") or
        "pyodide" in str(os.environ) or
        "emscripten" in str(getattr(__import__("platform", fromlist=[""]), "platform", lambda: "")()).lower()):
        _IS_WEB = True
except (AttributeError, ImportError, OSError, TypeError, RuntimeError):
    pass

_web_scores = None  # session fallback


def _web_load():
    global _web_scores
    if _web_scores is not None:
        return _web_scores
    try:
        from js import localStorage  # type: ignore
        raw = localStorage.getItem("bambooforest_highscores")
        if raw:
            data = json.loads(raw)
            _web_scores = data.get("high_scores", [])
            return _web_scores
    except (AttributeError, TypeError, RuntimeError, KeyError, json.JSONDecodeError) as e:
        log_event("warning", f"web highscores load failed, using []: {type(e).__name__}")
        pass
    _web_scores = []
    return _web_scores


def _web_save(scores):
    global _web_scores
    _web_scores = scores
    try:
        from js import localStorage  # type: ignore
        localStorage.setItem("bambooforest_highscores", json.dumps({"high_scores": scores}))
    except (AttributeError, TypeError, RuntimeError) as e:
        log_event("warning", f"web highscores save failed (in-mem only): {type(e).__name__}")
        pass  # in-memory only this session


def load_high_scores() -> list[dict]:
    """Load high scores from unified profile (high_scores + settings)."""
    data = _load_profile_data()
    scores = data.get("high_scores", [])
    if not isinstance(scores, list):
        scores = []
    # extra guard (migrate already cleaned, but belt+suspenders for rank)
    clean = [s for s in scores if isinstance(s, dict) and isinstance(s.get("score"), (int, float))]
    return sorted(clean, key=lambda s: s.get("score", 0), reverse=True) if clean else []


def save_high_score(score: int, level_reached: int) -> bool:
    """Add score if it qualifies for top 5. Persists in profile."""
    data = _load_profile_data()
    scores = data.get("high_scores", [])
    if not isinstance(scores, list):
        scores = []
    # only keep valid before append (highscore rank safety on bad data)
    scores = [s for s in scores if isinstance(s, dict) and "score" in s]
    entry = {"score": int(score), "level": int(level_reached)}
    scores.append(entry)
    scores.sort(key=lambda s: s.get("score", 0), reverse=True)
    scores = scores[:MAX_SCORES]
    data["high_scores"] = scores
    ok = _save_profile_data(data)
    made = (len(scores) < MAX_SCORES or entry["score"] >= scores[-1].get("score", 0)) if scores else True
    return ok and made


# ---------------------------------------------------------------------------
# Grove meta: essences (per biome) + grafts (player modifiers)
# Stored in the unified profile alongside high_scores + settings.
# ---------------------------------------------------------------------------

ESSENCE_BIOME_KEYS: list[str] = [
    "forest", "corrupted", "lair", "volcanic", "basalt", "desert",
    "cave", "salt", "mushroom", "forge", "tidal", "void", "gravity",
]

DEFAULT_ESSENCES: dict[str, int] = {k: 0 for k in ESSENCE_BIOME_KEYS}
DEFAULT_GRAFTS: list[str] = []


def load_essences() -> dict[str, int]:
    """Return essences counts (biome -> count)."""
    data = _load_profile_data()
    ess = data.get("essences", {}).copy()
    for k in ESSENCE_BIOME_KEYS:
        ess.setdefault(k, 0)
    return ess


def add_essence(biome: str) -> dict[str, int]:
    """Award +1 essence for the biome key. Persists. Returns new counts."""
    if biome not in ESSENCE_BIOME_KEYS:
        biome = "forest"
    data = _load_profile_data()
    ess = data.get("essences", {}).copy()
    for k in ESSENCE_BIOME_KEYS:
        ess.setdefault(k, 0)
    ess[biome] = ess.get(biome, 0) + 1
    data["essences"] = ess
    _save_profile_data(data)
    return ess


def spend_essence(n: int = 1) -> int:
    """Consume up to n essence from any biomes (for light Grove purchases).
    Returns actual number spent (0 if none available). Persists.
    """
    if n <= 0:
        return 0
    data = _load_profile_data()
    ess = data.get("essences", {}).copy()
    for k in ESSENCE_BIOME_KEYS:
        ess.setdefault(k, 0)
    remaining = n
    spent = 0
    for k in list(ess.keys()):
        if remaining <= 0:
            break
        take = min(ess.get(k, 0), remaining)
        if take > 0:
            ess[k] -= take
            spent += take
            remaining -= take
    data["essences"] = ess
    _save_profile_data(data)
    return spent


def spend_specific_essences(essence_keys: list[str]) -> bool:
    """Spend exactly 1 of each provided biome essence key (for 2-4 combine bench, richer combos).
    Returns True only if every key had >=1 and all were decremented. Persists.
    Supports daily bonus / overgrown clear extra sources via caller.
    """
    if not essence_keys or len(essence_keys) < 2 or len(essence_keys) > 5:
        return False
    data = _load_profile_data()
    ess = data.get("essences", {}).copy()
    for k in ESSENCE_BIOME_KEYS:
        ess.setdefault(k, 0)
    # verify availability (exact match, no over-spend)
    for ek in essence_keys:
        if ek not in ESSENCE_BIOME_KEYS or ess.get(ek, 0) < 1:
            return False
    # commit spend
    for ek in essence_keys:
        ess[ek] -= 1
    data["essences"] = ess
    return _save_profile_data(data)


def load_grafts() -> list[str]:
    """Return list of unlocked graft ids. Filter unknown to prevent silent bad state (hunter fix)."""
    data = _load_profile_data()
    gs = data.get("grafts", [])
    raw = list(gs) if isinstance(gs, list) else []
    KNOWN = {"lava_resist","glide_efficiency","dash_mastery","ice_armor","hp_boost","bamboo_yield","combo_bonus","weak_glide","vine_whip","chrono_step","spore_shield","essence_magnet","wild_weave","wind_ward","root_ward","echo_step","chrono_weave"}
    filtered = [g for g in raw if isinstance(g, str) and g in KNOWN]
    if len(filtered) != len(raw):
        try:
            from crash_logger import log_event
            dropped = [g for g in raw if g not in filtered]
            if dropped:
                log_event("warning", f"unknown graft(s) dropped on load: {dropped}")
        except Exception:
            pass
    return filtered


def unlock_graft(graft_id: str) -> bool:
    """Add graft if new. Persists. Returns True if newly added."""
    data = _load_profile_data()
    grafts = list(data.get("grafts", []))
    if graft_id in grafts:
        return False
    grafts.append(graft_id)
    data["grafts"] = grafts
    return _save_profile_data(data)


def get_profile_essences_and_grafts() -> tuple[dict[str, int], list[str]]:
    """Convenience: return (essences, grafts) snapshot."""
    data = _load_profile_data()
    ess = data.get("essences", {}).copy()
    for k in ESSENCE_BIOME_KEYS:
        ess.setdefault(k, 0)
    gr = list(data.get("grafts", []))
    return ess, gr


# ---------------------------------------------------------------------------
# Permanent unlocks (ice magic from boss, glide once collected, etc.)
# Stored under "unlocks": {"ice": true, "glide": true, ...}
# These are set on first achievement and survive deaths + level transitions.
# ---------------------------------------------------------------------------

DEFAULT_UNLOCKS: dict[str, bool] = {"ice": False, "glide": False, "overgrown": False}


def load_unlocks() -> dict[str, bool]:
    """Return current permanent unlocks (defaults false for unknown keys)."""
    data = _load_profile_data()
    u = data.get("unlocks", {})
    out = DEFAULT_UNLOCKS.copy()
    for k in DEFAULT_UNLOCKS:
        if k in u:
            out[k] = bool(u[k])
    return out


def save_unlock(key: str, value: bool = True) -> bool:
    """Persist a single unlock flag. Creates key if new. Returns success."""
    if key not in DEFAULT_UNLOCKS:
        # allow future keys but normalize
        pass
    data = _load_profile_data()
    unlocks = data.get("unlocks", {}).copy()
    unlocks[key] = bool(value)
    data["unlocks"] = unlocks
    data["version"] = SAVE_VERSION
    return _save_profile_data(data)


def save_unlocks(unlocks: dict[str, bool]) -> bool:
    """Persist multiple unlock flags at once (used on deaths/wins for reliability)."""
    data = _load_profile_data()
    cur = data.get("unlocks", {}).copy()
    for k, v in unlocks.items():
        cur[k] = bool(v)
    data["unlocks"] = cur
    data["version"] = SAVE_VERSION
    return _save_profile_data(data)


def get_best_score() -> int:
    """Return the highest saved score, or 0."""
    scores = load_high_scores()
    return scores[0]["score"] if scores else 0


# ---------------------------------------------------------------------------
# Profile / Accessibility settings (persisted with high scores)
# ---------------------------------------------------------------------------

DEFAULT_SETTINGS = DEFAULT_ACCESSIBILITY.copy()


def _load_profile_data():
    """Return full profile dict (high_scores + settings + unlocks + version). Web-aware.

    Migrates legacy plain high score JSONs and ensures version + unlocks keys.
    HARDENED: full profile keys with safe defaults on corruption.
    """
    full_default = {
        "version": SAVE_VERSION,
        "high_scores": [],
        "settings": DEFAULT_SETTINGS.copy(),
        "unlocks": DEFAULT_UNLOCKS.copy(),
        "bests": {"times": {}, "ghosts": {}},
        "essences": DEFAULT_ESSENCES.copy(),
        "grafts": [],
        "daily_completions": {},
        "daily_bests": {},
        "daily_streaks": {"current": 0, "longest": 0, "last_seed": 0},
        "perfect_streaks": {"current": 0, "longest": 0, "last_seed": 0},
        "ghost_library": {},
    }
    if _IS_WEB:
        try:
            from js import localStorage  # type: ignore
            raw = localStorage.getItem("bambooforest_profile")
            if raw:
                data = json.loads(raw)
                if isinstance(data, dict):
                    return _migrate_profile(data)
        except Exception as e:
            # Pyodide/JS access can fail in some embed contexts; fall back
            log_event("warning", f"web profile load failed, using defaults: {type(e).__name__}")
            pass
        return full_default.copy()
    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
        return _migrate_profile(data)
    except (FileNotFoundError, json.JSONDecodeError, KeyError, OSError, TypeError):
        return full_default.copy()


def _sanitize_bests(b: dict) -> dict:
    """Deep clean bests/ghosts for corruption (bad types, shapes, non-numeric)."""
    if not isinstance(b, dict):
        b = {}
    times = b.get("times") or {}
    if not isinstance(times, dict):
        times = {}
    clean_times = {}
    for k, v in times.items():
        try:
            clean_times[str(k)] = float(v)
        except (TypeError, ValueError):
            pass
    ghosts = b.get("ghosts") or {}
    if not isinstance(ghosts, dict):
        ghosts = {}
    clean_ghosts = {}
    for k, g in ghosts.items():
        if not isinstance(g, list):
            continue
        clean_g = []
        for s in g:
            try:
                if isinstance(s, (list, tuple)) and len(s) >= 4:
                    clean_g.append([round(float(s[0]), 3), int(s[1]), int(s[2]), bool(s[3])])
            except (TypeError, ValueError, IndexError):
                continue
        if clean_g:
            clean_ghosts[str(k)] = clean_g
    out = {"times": clean_times, "ghosts": clean_ghosts}
    if "splits" in b and isinstance(b["splits"], dict):
        out["splits"] = {str(k): [[int(i), float(t)] for i, t in (v or []) if isinstance(i, (int, str)) and isinstance(t, (int, float))] for k, v in b["splits"].items()}
    return out


def _migrate_profile(data: dict) -> dict:
    """Ensure keys and bump version. Safe for old files. Hardened for save corruption recovery.
    Sanitizes lists/dicts deeply (high_scores contents, bests, essences, streaks, grafts etc)
    so bad data never crashes callers. Safer defaults on bad data + streak persist guaranteed.
    """
    if not isinstance(data, dict):
        data = {}
    data.setdefault("version", 1)

    # high_scores: clean list of only valid dict entries (protects highscore rank/sort/save)
    hs = data.get("high_scores")
    clean_hs = []
    if isinstance(hs, list):
        for e in hs:
            if isinstance(e, dict):
                try:
                    sc = int(e.get("score", 0))
                    lv = int(e.get("level", 0))
                    clean_hs.append({"score": sc, "level": lv})
                except (TypeError, ValueError):
                    pass
    data["high_scores"] = clean_hs

    # settings
    st = data.get("settings")
    if not isinstance(st, dict):
        st = {}
    merged = DEFAULT_SETTINGS.copy()
    merged.update({k: st[k] for k in st if k in merged})
    data["settings"] = merged

    # unlocks
    u = data.get("unlocks")
    if not isinstance(u, dict):
        u = {}
    out_u = DEFAULT_UNLOCKS.copy()
    for k in out_u:
        if k in u:
            out_u[k] = bool(u[k])
    for k, v in u.items():
        out_u[str(k)] = bool(v)
    data["unlocks"] = out_u

    # overgrown cleared/mastery robustness (profile save hardening)
    oc = data.get("overgrown_cleared")
    data["overgrown_cleared"] = bool(oc) if oc is not None else False

    # bests + ghosts deep sanitize (best ghost robustness)
    bs = data.get("bests")
    data["bests"] = _sanitize_bests(bs if isinstance(bs, dict) else {})

    # grafts
    gr = data.get("grafts")
    data["grafts"] = [str(g) for g in gr if g] if isinstance(gr, (list, tuple)) else []

    # essences (prevents .copy / spend crashes on bad data)
    ess = data.get("essences")
    if not isinstance(ess, dict):
        ess = {}
    clean_ess = DEFAULT_ESSENCES.copy()
    for k in ESSENCE_BIOME_KEYS:
        try:
            clean_ess[k] = max(0, int(ess.get(k, 0)))
        except (TypeError, ValueError):
            pass
    data["essences"] = clean_ess

    # daily (streak persist)
    dc = data.get("daily_completions")
    data["daily_completions"] = {str(k): bool(v) for k, v in (dc or {}).items()} if isinstance(dc, dict) else {}
    db = data.get("daily_bests")
    if isinstance(db, dict):
        clean_db = {}
        for k, v in db.items():
            try:
                clean_db[str(k)] = float(v)
            except (TypeError, ValueError):
                pass
        data["daily_bests"] = clean_db
    else:
        data["daily_bests"] = {}

    def _clean_streak(s):
        if not isinstance(s, dict):
            s = {}
        return {
            "current": max(0, int(s.get("current", 0))),
            "longest": max(0, int(s.get("longest", 0))),
            "last_seed": max(0, int(s.get("last_seed", 0))),
        }
    data["daily_streaks"] = _clean_streak(data.get("daily_streaks"))
    data["perfect_streaks"] = _clean_streak(data.get("perfect_streaks"))

    gl = data.get("ghost_library")
    if not isinstance(gl, dict):
        gl = {}
    clean_gl = {}
    for k, entries in gl.items():
        if isinstance(entries, list):
            clean_ents = []
            for ent in entries:
                if isinstance(ent, list) and len(ent) >= 2:
                    try:
                        tm = float(ent[0])
                        g = ent[1] if isinstance(ent[1], list) else []
                        clean_ents.append([round(tm, 3), [[round(float(s[0]),3),int(s[1]),int(s[2]),bool(s[3])] for s in g if isinstance(s,(list,tuple)) and len(s)>=4]])
                    except Exception:
                        log_event("warning", "ghost_library entry parse failed during migrate")
            if clean_ents:
                clean_gl[str(k)] = clean_ents[:3]
    data["ghost_library"] = clean_gl

    if data.get("version", 1) < SAVE_VERSION:
        data["version"] = SAVE_VERSION
    return data


def _save_profile_data(data: dict) -> bool:
    """Write full profile. Web-aware. Returns success. Hardened against silent FS fails."""
    data = dict(data)  # copy
    data["version"] = SAVE_VERSION
    if _IS_WEB:
        try:
            from js import localStorage  # type: ignore
            localStorage.setItem("bambooforest_profile", json.dumps(data))
            return True
        except (AttributeError, TypeError, RuntimeError) as e:
            # Common pyodide case: no window / no LS in this context.
            # Caller gets False so it can decide (e.g. keep in mem for session).
            log_event("warning", f"web profile save failed (in-mem fallback): {type(e).__name__}")
            return False
    try:
        # Desktop: ensure dir exists (in case SAVE_FILE is in frozen exe dir)
        d = os.path.dirname(SAVE_FILE)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except (OSError, PermissionError, IOError) as e:
        # Report-ish: avoid total silent fail. Route to log_event so no silent failure.
        log_event("failure", f"profile write failed to {SAVE_FILE}: {type(e).__name__} {e}")
        try:
            print(f"[save] WARNING: failed writing profile to {SAVE_FILE}: {e}", file=sys.stderr)
        except Exception:
            pass
        return False


def load_settings() -> dict:
    """Load accessibility settings (merged with defaults for safety)."""
    data = _load_profile_data()
    settings = data.get("settings", {}).copy()
    # Merge missing keys with defaults (forward compat)
    for k, v in DEFAULT_SETTINGS.items():
        if k not in settings:
            settings[k] = v
    # Clamp to known sane values (support legacy keys from prior stubs for migration)
    pd = settings.get("particle_density", settings.get("particle_intensity", 1.0))
    settings["particle_density"] = max(0.5, min(1.5, float(pd)))
    si = settings.get("shake_intensity", settings.get("shake_scale", 1.0))
    settings["shake_intensity"] = max(0.5, min(1.5, float(si)))
    settings["text_scale"] = max(0.5, min(2.0, float(settings.get("text_scale", 1.0))))
    settings["reduced_motion"] = bool(settings.get("reduced_motion", False))
    settings["color_filter"] = max(0, min(4, int(settings.get("color_filter", 0))))
    settings["game_speed"] = max(0.5, min(1.5, float(settings.get("game_speed", 1.0))))
    return settings


def save_settings(settings: dict) -> bool:
    """Persist settings (keeps high scores)."""
    data = _load_profile_data()
    data["settings"] = {k: settings.get(k, DEFAULT_SETTINGS[k]) for k in DEFAULT_SETTINGS}
    return _save_profile_data(data)


# ---------------------------------------------------------------------------
# Speedrun bests: per-level best time + lightweight ghost (pos + facing samples)
# Stored under "bests": {"times": {"0": 42.3, ...}, "ghosts": {"0": [[t,x,y,facing], ...]}}
# ---------------------------------------------------------------------------

def _ensure_bests(data: dict) -> None:
    if "bests" not in data or not isinstance(data["bests"], dict):
        data["bests"] = {"times": {}, "ghosts": {}}
    data["bests"].setdefault("times", {})
    data["bests"].setdefault("ghosts", {})


def load_best_time(level: int) -> float | None:
    """Return best time for level (seconds) or None."""
    data = _load_profile_data()
    _ensure_bests(data)
    t = data["bests"]["times"].get(str(level))
    try:
        return float(t) if t is not None else None
    except (TypeError, ValueError):
        return None


def save_best_run(level: int, time_sec: float, ghost: list, splits: list | None = None) -> bool:
    """Save if better (or first). Stores time + ghost samples (+ splits for pro). Returns True if saved."""
    data = _load_profile_data()
    _ensure_bests(data)
    key = str(level)
    prev = data["bests"]["times"].get(key)
    try:
        if prev is not None and float(prev) <= float(time_sec):
            return False  # not better
    except (TypeError, ValueError):
        pass
    try:
        data["bests"]["times"][key] = round(float(time_sec), 3)
        # store only valid ghost entries (best ghost corruption guard)
        clean_ghost = []
        for s in (ghost or []):
            try:
                if isinstance(s, (list, tuple)) and len(s) >= 4:
                    clean_ghost.append([round(float(s[0]), 3), int(s[1]), int(s[2]), bool(s[3])])
            except (TypeError, ValueError, IndexError):
                continue
        data["bests"]["ghosts"][key] = clean_ghost
        if splits:
            data["bests"].setdefault("splits", {})[key] = [[int(i), float(t)] for i, t in (splits or [])]
        return _save_profile_data(data)
    except (TypeError, ValueError):
        return False


def get_best_ghost(level: int) -> list | None:
    """Return list of [t, x, y, facing] or None."""
    data = _load_profile_data()
    _ensure_bests(data)
    g = data["bests"]["ghosts"].get(str(level))
    if not g or not isinstance(g, list):
        return None
    # normalize shape (safe against corruption)
    out = []
    for s in g:
        try:
            if isinstance(s, (list, tuple)) and len(s) >= 4:
                out.append([float(s[0]), int(s[1]), int(s[2]), bool(s[3])])
        except (TypeError, ValueError, IndexError):
            continue
    return out if out else None


def get_best_time(level: int) -> float | None:
    """Alias for load_best_time (convenience)."""
    return load_best_time(level)


def get_ghost_splits(level: int) -> list:
    """Return list of [split_index, time] for the best ghost on level."""
    data = _load_profile_data()
    _ensure_bests(data)
    sp = data["bests"].get("splits", {}).get(str(level), [])
    return [[int(i), float(t)] for i, t in sp]


# ---------------------------------------------------------------------------
# Ghost library (pro level): keep several personal ghosts per level for practice
# "ghost_library": { "0": [ [time, ghost_list], ... ] up to 3 }
# ---------------------------------------------------------------------------

def save_ghost_to_library(level: int, time_sec: float, ghost: list) -> bool:
    data = _load_profile_data()
    _ensure_bests(data)
    lib = data.setdefault("ghost_library", {})
    key = str(level)
    entries = lib.setdefault(key, [])
    # store compact
    compact = [[round(float(s[0]), 3), int(s[1]), int(s[2]), bool(s[3])] for s in ghost]
    entries.append([round(float(time_sec), 3), compact])
    # keep only best 3 (by time)
    entries.sort(key=lambda e: e[0])
    lib[key] = entries[:3]
    return _save_profile_data(data)


def get_ghost_library(level: int):
    """Return list of [time, ghost] for the level."""
    data = _load_profile_data()
    lib = data.get("ghost_library", {})
    return lib.get(str(level), [])


# ---------------------------------------------------------------------------
# Daily challenge completion tracking + best times (expanded to full modifiers)
# "daily_completions": {"20260624": true, ...}
# "daily_bests": {"20260624": 1234.56, ...}  # best full-run clear time (sec) for seed
# Daily ghost support: visible in HUD/timer when daily_mode (per-level ghosts still used + chased for daily runs)
# ---------------------------------------------------------------------------

def mark_daily_complete(daily_seed: int) -> bool:
    """Mark this daily seed completed (on victory in daily mode). Persists."""
    data = _load_profile_data()
    dailies = data.setdefault("daily_completions", {})
    dailies[str(daily_seed)] = True
    return _save_profile_data(data)


def is_daily_complete(daily_seed: int) -> bool:
    """Return True if this daily seed (YYYYMMDD) was completed."""
    data = _load_profile_data()
    dailies = data.get("daily_completions", {})
    return bool(dailies.get(str(daily_seed), False))


def save_daily_best(daily_seed: int, time_sec: float) -> bool:
    """Save best full-run daily time for seed if improved (or first). Also marks complete. Persists."""
    data = _load_profile_data()
    dbests = data.setdefault("daily_bests", {})
    key = str(daily_seed)
    prev = dbests.get(key)
    if prev is not None and float(prev) <= float(time_sec):
        return False
    dbests[key] = round(float(time_sec), 3)
    data.setdefault("daily_completions", {})[key] = True
    return _save_profile_data(data)


def get_daily_best(daily_seed: int) -> float | None:
    """Return best full daily run time in seconds, or None."""
    data = _load_profile_data()
    dbests = data.get("daily_bests", {})
    t = dbests.get(str(daily_seed))
    return float(t) if t is not None else None


# ---------------------------------------------------------------------------
# Daily streaks (richer variety): consecutive days completed
# "daily_streaks": {"current": 3, "longest": 7, "last_seed": 20260624}
# ---------------------------------------------------------------------------

def update_daily_streak(daily_seed: int) -> int:
    """Update streak on complete. Returns current streak length."""
    data = _load_profile_data()
    streaks = data.setdefault("daily_streaks", {"current": 0, "longest": 0, "last_seed": 0})
    last = int(streaks.get("last_seed", 0))
    current = int(streaks.get("current", 0))
    if last == 0 or (daily_seed - last == 1):  # consecutive day
        current += 1
    else:
        current = 1
    streaks["current"] = current
    streaks["longest"] = max(int(streaks.get("longest", 0)), current)
    streaks["last_seed"] = daily_seed
    _save_profile_data(data)
    return current


def get_daily_streak() -> dict:
    """Return streak info dict."""
    data = _load_profile_data()
    return data.get("daily_streaks", {"current": 0, "longest": 0, "last_seed": 0})


# ---------------------------------------------------------------------------
# Perfect run streaks (for daily seeds): consecutive perfect (full HP) dailies.
# "perfect_streaks": {"current": 2, "longest": 5, "last_seed": 20260624}
# ---------------------------------------------------------------------------

def update_perfect_streak(daily_seed: int, is_perfect: bool) -> int:
    """Update perfect streak only on perfect daily completes. Returns current streak."""
    data = _load_profile_data()
    pstreaks = data.setdefault("perfect_streaks", {"current": 0, "longest": 0, "last_seed": 0})
    last = int(pstreaks.get("last_seed", 0))
    current = int(pstreaks.get("current", 0))
    if is_perfect:
        if last == 0 or (daily_seed - last == 1):
            current += 1
        else:
            current = 1
        pstreaks["current"] = current
        pstreaks["longest"] = max(int(pstreaks.get("longest", 0)), current)
        pstreaks["last_seed"] = daily_seed
    else:
        # break on non-perfect
        pstreaks["current"] = 0
        pstreaks["last_seed"] = daily_seed
    _save_profile_data(data)
    return int(pstreaks.get("current", 0))


def get_perfect_streak() -> dict:
    """Return perfect streak info dict."""
    data = _load_profile_data()
    return data.get("perfect_streaks", {"current": 0, "longest": 0, "last_seed": 0})


# ---------------------------------------------------------------------------
# Overgrown post-game challenge unlock (basic post-game area)
# Stored under unlocks["overgrown"] = true. Set on L18 victory + high essence.
# ---------------------------------------------------------------------------

def is_overgrown_unlocked() -> bool:
    """Return True if post-game Overgrown challenge is unlocked."""
    data = _load_profile_data()
    u = data.get("unlocks", {})
    return bool(u.get("overgrown", False))


def unlock_overgrown() -> bool:
    """Set the overgrown unlock flag. Returns success."""
    return save_unlock("overgrown")


def has_overgrown_mastery() -> bool:
    """Mastery for overgrown unlock + full rewards: 5+ grafts OR 25+ total essence.
    Called on L18 victory and for visible endgame rewards / aura.
    """
    grafts = load_grafts()
    ess = load_essences()
    total_ess = sum(ess.values()) if ess else 0
    return len(grafts) >= 5 or total_ess >= 25


def is_overgrown_mastered() -> bool:
    """Return True if player has fully cleared the Overgrown post-game (saved mastery)."""
    data = _load_profile_data()
    u = data.get("unlocks", {})
    return bool(u.get("overgrown_mastered", False)) or bool(data.get("overgrown_cleared", False))


def mark_overgrown_mastery() -> bool:
    """Persist full overgrown clear (mastery victory). Also ensures unlock. Returns success."""
    data = _load_profile_data()
    unlocks = data.get("unlocks", {}).copy()
    unlocks["overgrown"] = True
    unlocks["overgrown_mastered"] = True
    data["unlocks"] = unlocks
    data["overgrown_cleared"] = True
    return _save_profile_data(data)


# (high score load/save now implemented above using the profile helpers for unified persistence)
